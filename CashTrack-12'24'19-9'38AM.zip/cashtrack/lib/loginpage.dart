//Package Imports
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:fluttertoast/fluttertoast.dart';

//TextEntry Controllers
final usernameController = TextEditingController();
final passwordController = TextEditingController();

//Get Credentials Function
getStoredCredentials() async {
  final prefs = await SharedPreferences.getInstance();
  usernameStored = prefs.getString("username");
  passwordStored = prefs.getString("password");

  print("Stored Username: " + usernameStored);
  print("Stored Password: " + passwordStored);
}

//Validate Login Function
validateLogin(context) {
  usernameByUser = usernameController.text;
  passwordByUser = passwordController.text;
  getStoredCredentials();
  print("tried");
  if (usernameByUser == usernameStored && passwordByUser == passwordStored) {
    sendToastMessage("Login Successful");
    Navigator.of(context).pushNamed('/home');
  } else {
    sendToastMessage("Incorrect Login");
  }
}

//Navigate Function
void navigate(BuildContext ctx, pushName) {
  Navigator.of(ctx).pushNamed(pushName);
  //Navigator.push(ctx, new MaterialPageRoute(builder: (_) =>
  //new SignUpScreen()));
}

//Send Toast Function
void sendToastMessage(message) {
  print(message);
  Fluttertoast.showToast(
      msg: message,
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
      timeInSecForIos: 1,
      textColor: Colors.white,
      fontSize: 16.0);
}

//Global Variables
var usernameStored = "";
var passwordStored = "";

var usernameByUser = "err";
var passwordByUser = "err";

//LoginPage Class
class LoginInPage extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return new MaterialApp(
      home: Scaffold(
        body: Container(
          child: Container(
              width: double.infinity,
              height: double.infinity,
              decoration: BoxDecoration(
                  gradient: LinearGradient(
                      begin: Alignment.topRight,
                      end: Alignment.bottomLeft,
                      colors: [Colors.white, Colors.white70])),
              child: Column(
                children: <Widget>[
                  Container(
                    height: 310,
                    decoration: BoxDecoration(
                        image: DecorationImage(
                          fit: BoxFit.fill,
                          image: AssetImage('lib/images/background.png'),
                        )),
                  ),
                  Container(
                    height: 30,
                  ),
                  Container(
                    width: 350,
                    decoration: new BoxDecoration(
                        color: Colors.white,
                        borderRadius: new BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.purple.shade100,
                            blurRadius: 30.0,
                          )
                        ]),
                    child: Column(
                      children: <Widget>[
                        Container(
                          padding: const EdgeInsets.all(14.0),
                          alignment: Alignment.centerLeft,
                          child: Text(
                            "Sign Up",
                            style: new TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 30),
                          ),
                        ),
                        Container(
                            padding: const EdgeInsets.symmetric(horizontal: 15.0),
                            width: 350,
                            height: 80,
                            child: TextField(
                              controller: usernameController,
                              decoration: InputDecoration(
                                hintText: "Username",
                              ),
                            )),
                        Container(
                            padding: const EdgeInsets.symmetric(horizontal: 15.0),
                            alignment: Alignment.topRight,
                            width: 350,
                            height: 80,
                            child: TextField(
                              controller: passwordController,
                              decoration: InputDecoration(
                                hintText: "Password",
                              ),
                            )),
                      ],
                    ),
                  ),
                  Container(
                    height: 15,
                  ),
                  Container(
                      padding: const EdgeInsets.symmetric(horizontal: 15.0),
                      child: InkWell(
                        splashColor: Colors.black,
                        onTap: () => navigate(context, '/signuppage'),
                        child: Text(
                          "Forgot Password?",
                          style: new TextStyle(
                              fontSize: 17,
                              color: Colors.grey,
                              fontWeight: FontWeight.bold),
                        ),
                      )),
                  Container(
                    height: 40,
                  ),
                  Container(
                    height: 50,
                    width: 280,
                    child: SizedBox(
                      height: 50,
                      width: 380,
                      child: RaisedButton(
                        shape: RoundedRectangleBorder(
                          borderRadius: new BorderRadius.circular((20.0)),
                        ),
                        child: Text(
                          'Log In',
                          style: TextStyle(fontSize: 17),
                        ),
                        onPressed: () => validateLogin(context),
                        textColor: Colors.white,
                        color: Colors.deepPurple,
                      ),
                    ),
                  ),
                  Container(
                    height: 20,
                  ),
                  InkWell(
                    child: Text(
                      "Create an Account",
                      style: TextStyle(
                          fontSize: 16,
                          color: Colors.grey,
                          fontWeight: FontWeight.bold),
                    ),
                    splashColor: Colors.black,
                    onTap: () => navigate(context, '/signuppage'),
                  )
                ],
              )),
        ),
      ),
    );
  }
}

//Fade Transition Class
class FadeRouteBuilder<T> extends PageRouteBuilder<T> {
  final Widget page;

  FadeRouteBuilder({@required this.page})
      : super(
    pageBuilder: (context, animation1, animation2) => page,
    transitionsBuilder: (context, animation1, animation2, child) {
      return FadeTransition(opacity: animation1, child: child);
    },
  );
}