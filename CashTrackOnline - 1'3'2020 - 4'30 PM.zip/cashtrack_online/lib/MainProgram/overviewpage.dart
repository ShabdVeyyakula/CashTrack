//Library Imports
import 'dart:collection';

import 'package:cashtrack_online/dataManagement/datamanagement.dart';
import 'package:cashtrack_online/applicationManagement.dart';
import 'package:cashtrack_online/loginpage.dart';
import 'package:firebase_database/firebase_database.dart';

//Package Imports
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:awesome_dialog/awesome_dialog.dart';
import 'dart:async';

//Stateful Widget Class
class OverViewPage extends StatefulWidget {
  @override
  OverViewPageState createState() => OverViewPageState();
}

//State Class
class OverViewPageState extends State<OverViewPage> {
  //Instance Variables
  var databaseReference = FirebaseDatabase.instance.reference();
  var applicationManagementInstance = ApplicationManagement();
  var dataManagementInstance = DataManagement();

  //Global Variables
  var p = [];

  Future<List> updateListData() async {
    await checkServerStatus();
    p = await dataManagementInstance.getAllPurchaseData();
    await print("OLD P is: " + p.toString());
  }

  void initState() {
    //getTotalYearlyCost();
    super.initState();
  }

  checkServerStatus() async {
    var state = await applicationManagementInstance.CheckServersState();
    var shutdownMessage =
        await applicationManagementInstance.getShutdownMessage();
    print("working");
    print(state.toString());

    if (state == false) {
      showAlertDialog(shutdownMessage);
    }
  }

  showAlertDialog(shutdownMessage) {
    AwesomeDialog(
        context: context,
        dialogType: DialogType.WARNING,
        animType: AnimType.SCALE,
        tittle: 'Error',
        desc: 'Servers are down \n $shutdownMessage',
        onDissmissCallback: () => {SystemNavigator.pop()},
        btnOkText: 'Exit App',
        dismissOnTouchOutside: false,
        //btnCancelOnPress: () {SystemNavigator.pop();},
        btnOkOnPress: () {
          SystemNavigator.pop();
        }).show();
  }

  //Main GUI BUILD for Class
  @override
  Widget build(BuildContext context) {
    SystemChrome.setEnabledSystemUIOverlays([]);
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    return new MaterialApp(
        home: Scaffold(
      backgroundColor: Colors.grey.shade200,
      body: Flex(
         direction: Axis.vertical,
        children: <Widget>[
          Expanded(
            child: SafeArea(
              child: Container(
                color: Colors.white10,
                child: Column(
                  children: <Widget>[
                    new Stack(
                      children: <Widget>[
                        Container(
                          height: 310,
                          decoration: BoxDecoration(
                              gradient: LinearGradient(
                                  begin: Alignment.topRight,
                                  end: Alignment.bottomLeft,
                                  colors: [
                                    Colors.orangeAccent,
                                    Colors.red,
                                  ])),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(vertical: 120),
                          alignment: Alignment.center,
                          child: Text(
                            "Monthly Spendings",
                            style: TextStyle(
                                fontSize: 18,
                                color: Colors.white,
                                fontFamily: 'RobotoMono'),
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(vertical: 150),
                          alignment: Alignment.center,
                          child: Text(
                            "\$9,321.29",
                            style: TextStyle(
                              fontSize: 40,
                              color: Colors.white,
                            ),
                          ),
                        ),
                        Positioned(
                          top: 275,
                          left: 22,
                          child: Container(
                            height: 65,
                            width: 370,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: new BorderRadius.circular(5),
                              boxShadow: [
                                new BoxShadow(color: Colors.grey, blurRadius: 30)
                              ],
                            ),
                            child: Column(
                              children: <Widget>[
                                Text(
                                  "\$202,321.29",
                                  style: TextStyle(fontSize: 35, color: Colors.black),
                                ),
                                Text(
                                  "Yearly Spendings",
                                  style: TextStyle(
                                    color: Colors.grey,
                                    fontSize: 15,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                    Container(
                      height: 3,
                    ),
                    Text(
                      "Recent Activity",
                      style: TextStyle(fontSize: 20),
                    ),
                    RaisedButton(
                      child: Text("Reload"),
                      onPressed: () => {
                        updateListData(),
                        setState(() {}),
                      },
                    ),
                    Stack(
                      children: <Widget>[
                        Container(
                          height: 252.0,
                          child: ListView.builder(
                            physics: BouncingScrollPhysics(),
                            scrollDirection: Axis.vertical,
                            itemCount: p.length,
                            itemBuilder: (context, int index) {
                              return Card(
                                child: InkWell(
                                  splashColor: Colors.grey,
                                  child: Container(
                                    padding: EdgeInsets.all(15),
                                    height: 109,
                                    width: 390,
                                    child: Column(
                                      children: <Widget>[

                                        Container(
                                          alignment: Alignment.centerLeft,
                                          child: Text(p[index][0],
                                              style: TextStyle(
                                                  color: Colors.black, fontSize: 20)),
                                        ),
                                        Container(
                                            alignment: Alignment.centerRight,
                                            child: Text("\$" + p[index][1].toString(),
                                                style: TextStyle(
                                                  color: Colors.black,
                                                  fontSize: 20,
                                                ))),
                                        Container(
                                          height: 0,
                                        ),
                                        Container(
                                            height: 30,
                                            alignment: Alignment.bottomLeft,
                                            child: Text(p[index][2],
                                                style:
                                                TextStyle(color: Colors.grey))),
                                      ],
                                    ),
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                      ],
                    )
                  ],
                ),
              ),
            ),
          )
        ],
      )
    ));
  }
}
