//Class Imports
import 'loginpage.dart';
import 'signuppage.dart';
import 'homepage.dart';

//Library Imports
import 'package:flutter/material.dart';

//Main Run Function
void main() => runApp(SplashScreen());

//Splash Screen Class
class SplashScreen extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return new MaterialApp(
      home: LoginInPage(),
      routes: <String, WidgetBuilder>{
        '/loginpage': (BuildContext context) => new LoginInPage(),
        '/signuppage' : (BuildContext context) => new SignUpPage(),
        '/homepage' : (BuildContext context) => new MyApp(),
      },
    );
  }
}

//THINGS LEFT TO MAKE FOR THE APP
//TODO: Fix the overview screen reload button thing: make it work on screen init
//TODO: Add the backend for the add card section in add screen
//TODO: Make the cards show up in the cards screen
//TODO: Make avaliable payment methods show up when adding a purchase
//TODO: Add a settings screen




