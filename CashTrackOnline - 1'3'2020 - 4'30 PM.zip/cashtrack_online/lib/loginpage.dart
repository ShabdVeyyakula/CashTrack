//Package Imports
import 'dart:ui';
import 'package:shared_preferences/shared_preferences.dart';
import 'applicationManagement.dart';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'dataManagement/datamanagement.dart';
import 'package:flutter/painting.dart';
import 'package:flutter/services.dart';
import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:package_info/package_info.dart';

//TextEntry Controllers
final usernameController = TextEditingController();
final passwordController = TextEditingController();

var datamangementInstance = DataManagement();

//Navigate Function
Future navigate(BuildContext ctx, pushName) {
  Navigator.of(ctx).pushNamed(pushName);

}

//Send Toast Function
Future sendToastMessage(message) async {
  print(message);
  Fluttertoast.showToast(
      msg: message,
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
      timeInSecForIos: 1,
      textColor: Colors.white,
      fontSize: 16.0);
}

//Global Variables
var usernameStored = "";
var passwordStored = "";

var usernameByUser = "err";
var passwordByUser = "err";

//LoginPage Class
class LoginInPage extends StatefulWidget {
  LoginInPageState createState() => LoginInPageState();
}

class LoginInPageState extends State<LoginInPage> {
  @override
  var applicationManagementInstance = ApplicationManagement();

  getApplicationVersion() async {
    PackageInfo packageInfo = await PackageInfo.fromPlatform();
    String localVersion = packageInfo.version;
    print(localVersion);

    var latestVersion = await applicationManagementInstance.getLatestVersion();

    print("local version: "+ localVersion);
    print("latest version: "+ latestVersion);
    if(localVersion != latestVersion){
      alertDialogForVersion();
    }


  }
  checkServerStatus() async {
    var state = await applicationManagementInstance.CheckServersState();
    var shutdownMessage = await applicationManagementInstance.getShutdownMessage();
    print("working");
    print(state.toString());

    if (state == false) {
      sendToastMessage("Servers Are Down");
      showAlertDialogforServerShutdown(shutdownMessage);
    }
  }

  showAlertDialogforServerShutdown(shutdownMessage) {
    AwesomeDialog(context: context,
        dialogType: DialogType.WARNING,
        animType: AnimType.SCALE,
        tittle: 'Error',
        desc: 'Servers are down \n $shutdownMessage',
        onDissmissCallback: () => {SystemNavigator.pop()},
        btnOkText: 'Exit App',
        dismissOnTouchOutside: false,
        //btnCancelOnPress: () {SystemNavigator.pop();},
        btnOkOnPress: () {SystemNavigator.pop();}).show();

  }
  alertDialogForVersion() {
    AwesomeDialog(context: context,
        dialogType: DialogType.ERROR,
        animType: AnimType.SCALE,
        tittle: 'Error',
        desc: 'You do not have the latest version \n please download the latest version \n from your playstore or apple store',
        onDissmissCallback: () => {SystemNavigator.pop()},
        btnOkText: 'Exit App',
        dismissOnTouchOutside: false,
        //btnCancelOnPress: () {SystemNavigator.pop();},
        btnOkOnPress: () {SystemNavigator.pop();}).show();
  }


  void initState() {
    checkServerStatus();
    getApplicationVersion();
    super.initState();
  }

  final Shader linearGradient = LinearGradient(
    colors: [Colors.orange, Colors.redAccent],
  ).createShader(Rect.fromLTWH(0.0, 0.0, 200.0, 70.0));

  var displayMessage = "";
  var displayButtonMessage = "Sign In";

  @override
  Widget build(BuildContext context) {
    SystemChrome.setEnabledSystemUIOverlays([]);
    return new MaterialApp(
      home: Scaffold(
        body: Flex(
          direction: Axis.horizontal,
          children: <Widget>[
            Expanded(
                child: Container(
                    width: double.infinity,
                    height: 790,
                    child: Column(
                      children: <Widget>[
                        Stack(
                          children: <Widget>[
                            Container(
                              height: 748,
                              width: double.infinity,
                            ),
                            Positioned(
                              child: Container(
                                height: 240,
                                decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                      colors: [Colors.orange, Colors.redAccent],
                                      begin: Alignment.bottomLeft,
                                      end: Alignment.topRight,
                                    )),
                              ),
                            ),
                            Positioned(
                              top: 153,
                              left: 10,
                              child: Text(
                                'Cash',
                                style: new TextStyle(
                                  fontSize: 80.0,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                            Positioned(
                              top: 221,
                              left: 25,
                              child: Text(
                                'Track',
                                style: new TextStyle(
                                    fontSize: 80.0,
                                    fontWeight: FontWeight.bold,
                                    foreground: Paint()
                                      ..shader = linearGradient),
                              ),
                            ),
                            Positioned(
                              top: 340,
                              left: 30,
                              child: Container(
                                width: 350,
                                decoration: new BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: new BorderRadius.circular(12),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.deepOrangeAccent,
                                        blurRadius: 25.0,
                                      )
                                    ]),
                                child: Column(
                                  children: <Widget>[
                                    Container(
                                      padding: const EdgeInsets.all(14.0),
                                      alignment: Alignment.centerLeft,
                                      child: Text(
                                        "Sign In",
                                        style: new TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 30,
                                          foreground: Paint()
                                            ..shader = linearGradient,
                                        ),
                                      ),
                                    ),
                                    Container(
                                      height: 5,
                                    ),
                                    Container(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 15.0),
                                        width: 350,
                                        height: 80,
                                        child: TextField(
                                          controller: usernameController,
                                          decoration: InputDecoration(
                                            hintText: "Username",
                                          ),
                                        )),
                                    Container(
                                      height: 5,
                                    ),
                                    Container(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 15.0),
                                        alignment: Alignment.topRight,
                                        width: 350,
                                        height: 80,
                                        child: TextField(
                                          obscureText: true,
                                          controller: passwordController,
                                          decoration: InputDecoration(
                                            hintText: "Password",
                                          ),
                                        )),
                                    Container(
                                      alignment: Alignment.centerLeft,
                                      padding: EdgeInsets.only(
                                        left: 10,
                                      ),
                                      child: Text(
                                        displayMessage,
                                        style: TextStyle(
                                            fontSize: 15, color: Colors.red),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Positioned(
                                top: 690,
                                left: 130,
                                child: InkWell(
                                  child: Text(
                                    "Create an Account",
                                    style: TextStyle(
                                      fontSize: 16,
                                      color: Colors.grey,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  splashColor: Colors.grey,
                                  onTap: () =>
                                      navigate(context, '/signuppage'),
                                )),
                            Positioned(
                              height: 50,
                              width: 250,
                              top: 630,
                              left: 75,
                              child: RaisedGradientButton(
                                  height: 100,
                                  child: Text(
                                    displayButtonMessage,
                                    style:
                                    TextStyle(color: Colors.white, fontSize: 15),
                                  ),
                                  gradient: LinearGradient(
                                    colors: <Color>[Colors.orange, Colors.redAccent],
                                  ),
                                  onPressed: () {
                                    Future validateLogin(context) async {
                                      try {
                                        print("tried");
                                        print(
                                            "username stored is: " + usernameStored);
                                        print("usernameByuser is: " + usernameByUser);

                                        if (usernameByUser == usernameStored &&
                                            passwordByUser == passwordStored) {
                                          await sendToastMessage("Login Successful");
                                          final prefs = await SharedPreferences.getInstance();
                                          prefs.setString("storedUser", usernameByUser);
                                          await Navigator.of(context).pushNamed('/homepage');
                                        } else {
                                          await sendToastMessage("Incorrect Login");
                                          setState(() {
                                            displayMessage =
                                            "Incorrect login credentials";
                                            displayButtonMessage = "Sign In";
                                          });
                                        }
                                      } catch (e) {
                                        await sendToastMessage("Login Error");
                                        await print(e);
                                      }
                                    }

                                    setState(() {
                                      displayButtonMessage = "Validating...";
                                    });
                                    //Validate Login Function

                                    //Get Credentials Function
                                    getStoredCredentials(username, context) async {
                                      usernameByUser = usernameController.text;
                                      passwordByUser = passwordController.text;

                                      var data = await datamangementInstance
                                          .getLoginCredentials(username);
                                      usernameStored = data[0];
                                      passwordStored = data[1];

                                      print("New is:" + data.toString());

                                      Future.delayed(Duration(seconds: 1),
                                              () => validateLogin(context));
                                    }

                                    getStoredCredentials(
                                        usernameController.text, context);
                                  }),
                            ),
                          ],
                        ),
                      ],
                    )),
            )
          ],

      ),
    ));
  }
}

//Fade Transition Class
class FadeRouteBuilder<T> extends PageRouteBuilder<T> {
  final Widget page;

  FadeRouteBuilder({@required this.page})
      : super(
    pageBuilder: (context, animation1, animation2) => page,
    transitionsBuilder: (context, animation1, animation2, child) {
      return FadeTransition(opacity: animation1, child: child);
    },
  );
}

class RaisedGradientButton extends StatelessWidget {
  final Widget child;
  final Gradient gradient;
  final double width;
  final double height;
  final Function onPressed;

  const RaisedGradientButton({
    Key key,
    @required this.child,
    this.gradient,
    this.width = double.infinity,
    this.height = 50.0,
    this.onPressed,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      height: 50.0,
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          gradient: gradient,
          boxShadow: [
            BoxShadow(
              color: Colors.grey[500],
              offset: Offset(0.0, 1.5),
              blurRadius: 1.5,
            ),
          ]),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
            onTap: onPressed,
            child: Center(
              child: child,
            )),
      ),
    );
  }
}