import 'package:cashtrack_online/loginpage.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';


class DataManagement {

  var databaseReference = FirebaseDatabase.instance.reference().child("UserData");

  //PURCHASE DATA MANAGEMENT FUNCTIONS

  //Save Purchase Function
  savePurchase(String store, double amount, String date, String card) async {
    final prefs = await SharedPreferences.getInstance();
    String storedUser = await prefs.getString("storedUser");

    print("STORED USER IS: " + storedUser.toString());

    DataSnapshot purchaseNumberSnapshot = await databaseReference
        .reference()
        .child(storedUser)
        .child("purchaseNumber")
        .once();

    var purchaseNumber = await purchaseNumberSnapshot.value;

    databaseReference.child(storedUser).child("Purchases").child(purchaseNumber.toString()).child("Store").set(store);
    databaseReference.child(storedUser).child("Purchases").child(purchaseNumber.toString()).child("Amount").set(amount);
    databaseReference.child(storedUser).child("Purchases").child(purchaseNumber.toString()).child("Date").set(date);
    databaseReference.child(storedUser).child("Purchases").child(purchaseNumber.toString()).child("Card").set(card);
    databaseReference.child(storedUser).child("purchaseNumber").set(purchaseNumber+1);

  }

  //Get Purchase Function
  getAllPurchaseData() async{
    final prefs = await SharedPreferences.getInstance();
    String storedUser = await prefs.getString("storedUser");

    List allPurchaseData = [];

    DatabaseReference databaseRef = FirebaseDatabase.instance.reference().child("UserData").child(storedUser).child("Purchases");

    await databaseRef.once().then((DataSnapshot snapshot) {
      print("PRINT SNAPSHOT:" + snapshot.value.toString());
      Map<dynamic,dynamic> map = snapshot.value;
      map.forEach((key, value) {
        //print('$key: $value');
        allPurchaseData.add([value["Store"], value["Amount"], value["Date"].toString()]);
      });
    });
    //print(allPurchaseData);

    return allPurchaseData;
  }

  //Save login credentials
  saveLoginCredentials(String username, String password, String email){
      databaseReference.child(username).child("username").set(username);
      databaseReference.child(username).child("email").set(email);
      databaseReference.child(username).child("password").set(password);
      databaseReference.child(username).child("purchaseNumber").set(0);

    }

    Future<List> getLoginCredentials(username) async {
      DataSnapshot usernameSnapshot = await databaseReference
          .reference()
          .child(username)
          .child("username")
          .once();
      DataSnapshot passwordSnapshot = await databaseReference
          .reference()
          .child(username)
          .child("password")
          .once();

      print("Val is: " + [usernameSnapshot.value.toString(), passwordSnapshot.value.toString()].toString());

      var valueList = [usernameSnapshot.value.toString(), passwordSnapshot.value.toString()];

      print("value list is: " + valueList.toString());
      return valueList;

    }

  Future<String> checkUserNameExists(username) async {
    DataSnapshot dataSnapshot = await databaseReference
        .reference()
        .child(username)
        .child("username")
        .once();

    return dataSnapshot.value.toString();
  }

  Future<int> getPurchaseCost(index) async {
    final prefs = await SharedPreferences.getInstance();
    var storedUser = await prefs.getString("storedUser");
    print("STORED USER IS: " + storedUser);

    DataSnapshot dataSnapshot = await databaseReference
        .reference()
        .child(storedUser)
        .child("Purchases")
        .child(index)
        .child("Amount")
        .once();

    return int.parse(dataSnapshot.value);




  }


}
