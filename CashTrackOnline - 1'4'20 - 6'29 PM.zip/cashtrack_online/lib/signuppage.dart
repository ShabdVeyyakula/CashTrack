//Package Imports
import 'package:cashtrack_online/loginpage.dart';
import 'package:fluttertoast/fluttertoast.dart';

import 'package:flutter/material.dart';
import 'dataManagement/datamanagement.dart';
import 'package:flutter/services.dart';

//TextEntry Controllers
final usernameController = TextEditingController();
final emailController = TextEditingController();
final passwordController = TextEditingController();
final repeatPasswordController = TextEditingController();

var datamangementInstance = DataManagement();

//Navigate Function
navigate(BuildContext ctx, pushName) async{
  Navigator.of(ctx).pushNamed(pushName);
}

//Send Toast Function
sendToastMessage(message) async {
  Fluttertoast.showToast(
      msg: message,
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
      timeInSecForIos: 1,
      textColor: Colors.white,
      fontSize: 16.0);

}

//Global Variables
var usernameByUser = "err";
var emailByUser = "err";
var passwordByUser = "err";
var repeatPasswordByUser = "err";


class SignUpPage extends StatefulWidget{
  @override
  SignUpPageState createState() => SignUpPageState();
}
//LoginPage Class
class SignUpPageState extends State<SignUpPage>{

  Future signUpButtonIsPressed(context) async {
    usernameByUser = usernameController.text;
    emailByUser = emailController.text;
    passwordByUser = passwordController.text;
    repeatPasswordByUser = repeatPasswordController.text;

    print([usernameByUser, passwordByUser]);

    String exists = await datamangementInstance.checkUserNameExists(usernameByUser);
    print('Exists: ' + exists.toString());

    if (exists == "null"){
      print("working");
      if(passwordByUser == repeatPasswordByUser){
        print("working");
        await datamangementInstance.saveLoginCredentials(usernameByUser, passwordByUser, emailByUser);

        await sendToastMessage("Successfully Signed Up");
        await navigate(context, "/loginpage");

      } else{
        await sendToastMessage("Password and repeat password don't match");
      }
    }else{
      print("working");
      await sendToastMessage("Username already exists");
    }

  }
  @override
  Widget build(BuildContext context) {
    SystemChrome.setEnabledSystemUIOverlays([]);
    return new MaterialApp(
      home: Scaffold(
        body: SafeArea(
          child: Container(
              width: double.infinity,
              height: 790,
              decoration: BoxDecoration(
                  gradient: LinearGradient(
                      begin: Alignment.topRight,
                      end: Alignment.bottomLeft,
                      colors: [Colors.white, Colors.white70])),
              child: Column(
                children: <Widget>[
                  Container(
                    height: 200,
                    decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [Colors.orange, Colors.redAccent],
                          begin: Alignment.bottomLeft,
                          end: Alignment.topRight,
                        )

                    ),
                  ),
                  Container(
                    height: 50,
                  ),
                  Container(
                    width: 350,
                    decoration: new BoxDecoration(
                        color: Colors.white,
                        borderRadius: new BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.deepOrangeAccent,
                            blurRadius: 15.0,
                          )
                        ]),
                    child: Column(
                      children: <Widget>[
                        Container(
                          padding: const EdgeInsets.all(14.0),
                          alignment: Alignment.centerLeft,
                          child: Text(
                            "Sign Up",
                            style: new TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 30),
                          ),
                        ),
                        Container(
                            padding: const EdgeInsets.symmetric(horizontal: 15.0),
                            width: 350,
                            height: 80,
                            child: TextField(
                              controller: usernameController,
                              decoration: InputDecoration(
                                hintText: "Username",
                              ),
                            )),
                        Container(
                            padding: const EdgeInsets.symmetric(horizontal: 15.0),
                            width: 350,
                            height: 80,
                            child: TextField(
                              controller: emailController,
                              decoration: InputDecoration(
                                hintText: "Email",
                              ),
                            )),
                        Container(
                            padding: const EdgeInsets.symmetric(horizontal: 15.0),
                            width: 350,
                            height: 80,
                            child: TextField(
                              obscureText: true,
                              controller: passwordController,
                              decoration: InputDecoration(
                                hintText: "Password",
                              ),
                            )),
                        Container(
                            padding: const EdgeInsets.symmetric(horizontal: 15.0),
                            alignment: Alignment.topRight,
                            width: 350,
                            height: 80,
                            child: TextField(
                              obscureText: true,
                              controller: repeatPasswordController,
                              decoration: InputDecoration(
                                hintText: "Repeat Password",
                              ),
                            )),
                      ],
                    ),
                  ),
                  Container(
                    height: 30,
                  ),
                  Container(
                    alignment: Alignment.center,
                    height: 50,
                    width: 280,
                    child: SizedBox(
                      height: 50,
                      width: 380,
                      child: RaisedButton(
                        shape: RoundedRectangleBorder(
                          borderRadius: new BorderRadius.circular((20.0)),
                        ),
                        child: Text(
                          'Sign Up',
                          style: TextStyle(fontSize: 17),
                        ),
                        onPressed: () => signUpButtonIsPressed(context),
                        textColor: Colors.white,
                        color: Colors.deepOrange,
                      ),
                    ),
                  ),
                  Container(
                    height: 10,
                  ),
                  InkWell(
                    child: Text(
                      "Login to an Account",
                      style: TextStyle(
                          fontSize: 16,
                          color: Colors.grey,
                          fontWeight: FontWeight.bold),
                    ),
                    splashColor: Colors.black,
                    onTap: () => navigate(context, '/loginpage'),
                  )
                ],
              )),
        ),
      ),
    );
  }
}

//Fade Transition Class
class FadeRouteBuilder<T> extends PageRouteBuilder<T> {
  final Widget page;

  FadeRouteBuilder({@required this.page})
      : super(
    pageBuilder: (context, animation1, animation2) => page,
    transitionsBuilder: (context, animation1, animation2, child) {
      return FadeTransition(opacity: animation1, child: child);
    },
  );
}