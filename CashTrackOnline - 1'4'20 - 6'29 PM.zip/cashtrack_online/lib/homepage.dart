//Package Imports
import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';


//Screen Imports
import 'MainProgram/overviewpage.dart';
//import 'MainProgram/cardspage.dart';
import 'MainProgram/addscreen.dart';

//Main App that runs Homepage
class MyApp extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    SystemChrome.setEnabledSystemUIOverlays([]);
    return HomePage();
  }
}
//Homepage Class for bottom navigation bar
class HomePage extends State<MyApp> {
  int selectedPage = 1;
  final pageOptions = [
    AddPageScreenMain(),
    OverViewPage(),
    OverViewPage(),//CardsPage(),
    OverViewPage(),
  ];
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return new MaterialApp(
        home: Scaffold(
          body: pageOptions[selectedPage],
          bottomNavigationBar: CurvedNavigationBar(
            items: <Widget>[
              Icon(Icons.add_to_photos, size: 20, color: Colors.black,),
              Icon(Icons.attach_money, size: 20, color: Colors.black,),
              Icon(Icons.credit_card, size: 20, color: Colors.black,),
              Icon(Icons.settings, size: 20, color: Colors.black,),
            ],
            index: 1,
            color: Colors.white,
            backgroundColor: Colors.grey.shade200,
            buttonBackgroundColor: Colors.white,
            animationDuration: Duration(
                milliseconds: 500
            ),
            animationCurve: Curves.fastLinearToSlowEaseIn,
            onTap: (int index) => {
              setState((){
                selectedPage = index;
              })
            },
          ),
        ));
  }
}
