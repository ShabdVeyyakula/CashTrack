import 'dart:ui';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'MainProgram/overviewpage.dart';

class MyApp extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    return HomePage();
  }
}
class HomePage extends State<MyApp> {
  int selectedPage = 0;
  final pageOptions = [
    OverViewPage(),
    Text('Item 2'),
    Text('Item 3'),
    Text('Cards'),
  ];
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return new MaterialApp(
        home: Scaffold(
          body: pageOptions[selectedPage],
          bottomNavigationBar: BottomNavigationBar(
            currentIndex: selectedPage,
            selectedItemColor: Colors.white,
            onTap: (int index) => {
              setState((){
                selectedPage = index;
              })
            },
            items: [
              BottomNavigationBarItem(
                icon: Icon(Icons.money_off),
                    activeIcon: Icon(Icons.monetization_on),
                    title: Text('Summary'),
                  backgroundColor: Colors.deepOrange
              ),
              BottomNavigationBarItem(
                  icon: Icon(Icons.add_to_photos),
                  title: Text('Add'),
                backgroundColor: Colors.deepOrange
              ),
              BottomNavigationBarItem(
                  icon: Icon(Icons.credit_card),
                  title: Text('Cards'),
                  backgroundColor: Colors.deepOrange
              ),
              BottomNavigationBarItem(
                  icon: Icon(Icons.settings),
                  title: Text('Settings'),
                  backgroundColor: Colors.deepOrange
              ),
            ],
          ),
        ));
  }
}
