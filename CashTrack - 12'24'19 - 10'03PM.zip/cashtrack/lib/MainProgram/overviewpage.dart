import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class OverViewPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    SystemChrome.setEnabledSystemUIOverlays([]);
    SystemChrome.setPreferredOrientations([ DeviceOrientation.portraitUp, DeviceOrientation.portraitDown, ]);
    return new MaterialApp(
        home: Scaffold(
          body: Container(
            color: Colors.white10,
            child: Column(
              children: <Widget>[
                new Stack(
                  children: <Widget>[
                    Container(
                      height: 310,
                      decoration: BoxDecoration(
                          gradient: LinearGradient(
                              begin: Alignment.topRight,
                              end: Alignment.bottomLeft,
                              colors: [
                                Colors.orangeAccent,
                                Colors.red,
                              ])),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(vertical: 120),
                      alignment: Alignment.center,
                      child: Text(
                        "Monthly Spendings",
                        style: TextStyle(
                            fontSize: 18,
                            color: Colors.white,
                            fontFamily: 'RobotoMono'),
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(vertical: 150),
                      alignment: Alignment.center,
                      child: Text(
                        "\$9,321.29",
                        style: TextStyle(fontSize: 40, color: Colors.white,),
                      ),
                    ),
                    Positioned(
                      top: 275,
                      left: 22,
                      child: Container(
                        height: 65,
                        width: 370,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: new BorderRadius.circular(5),
                          boxShadow: [
                            new BoxShadow(
                                color: Colors.grey,
                                blurRadius: 30
                            )
                          ],
                        ),
                        child: Column(
                          children: <Widget>[
                            Text(
                              "\$202,321.29",
                              style: TextStyle(
                                  fontSize: 35, color: Colors.black),
                            ),
                            Text(
                              "Yearly Spendings",
                              style: TextStyle(color: Colors.grey, fontSize: 15,), ),
                          ],

                        ),
                      ),
                    ),
                  ],
                ),
                Container(
                  height: 110,
                  width: 390,
                  decoration: BoxDecoration(color: Colors.white70, boxShadow: [
                    new BoxShadow(color: Colors.grey, blurRadius: 20)
                  ]),
                  child: Column(
                    children: <Widget>[
                      Container(
                        padding: const EdgeInsets.symmetric(vertical: 0),
                        alignment: Alignment.center,
                        child: Text(
                          "LATEST ACTIVITY",
                          style: TextStyle(fontSize: 20, color: Colors.black),
                        ),
                      ),
                      Container(
                        height: 80,
                        child: ListView(
                          scrollDirection: Axis.horizontal,
                          children: <Widget>[
                            Card(
                              color: Colors.deepPurpleAccent,
                              child: InkWell(
                                splashColor: Colors.grey,
                                onTap: () => print("Hello"),
                                child: Row(
                                  children: <Widget>[
                                    Column(
                                      children: <Widget>[
                                        Container(
                                            padding: EdgeInsets.all(5),
                                            height: 70,
                                            width: 140,
                                            child: Column(children: <Widget>[
                                              Text(
                                                "Walmart",
                                                style: TextStyle(
                                                    fontSize: 25,
                                                    color: Colors.white),
                                              ),
                                              Text("\$29.99",
                                                  style: TextStyle(
                                                      fontSize: 25,
                                                      color: Colors.white))
                                            ])),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Card(
                              color: Colors.red,
                              child: InkWell(
                                splashColor: Colors.grey,
                                onTap: () => print("Hello"),
                                child: Container(
                                  height: 70,
                                  width: 140,
                                  padding: EdgeInsets.all(5),
                                  child: Column(
                                    children: <Widget>[
                                      Text(
                                        "Costco",
                                        style: TextStyle(
                                            fontSize: 25, color: Colors.white),
                                      ),
                                      Text("\$9.99",
                                          style: TextStyle(
                                              fontSize: 25,
                                              color: Colors.white))
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            Card(
                              color: Colors.blue,
                              child: InkWell(
                                splashColor: Colors.grey,
                                onTap: () => print("Hello"),
                                child: Container(
                                  height: 70,
                                  width: 140,
                                  padding: EdgeInsets.all(5),
                                  child: Column(
                                    children: <Widget>[
                                      Text(
                                        "Best Buy",
                                        style: TextStyle(
                                            fontSize: 25, color: Colors.white),
                                      ),
                                      Text("\$9.99",
                                          style: TextStyle(
                                              fontSize: 25,
                                              color: Colors.white))
                                    ],
                                  ),
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  height: 4,
                ),
                Stack(
                  children: <Widget>[
                    Container(
                      height: 275.0,
                      child: ListView(
                        scrollDirection: Axis.vertical,
                        children: <Widget>[
                          Column(
                            children: <Widget>[
                              Card(
                                child: InkWell(
                                  splashColor: Colors.grey,
                                  onTap: () => print("Hello"),
                                  child: Container(
                                    padding: EdgeInsets.all(15),
                                    height: 102,
                                    width: 390,
                                    child: Column(
                                      children: <Widget>[
                                        Container(
                                          alignment: Alignment.centerLeft,
                                          child: Text(
                                            "Payment",
                                            style: TextStyle(
                                                color: Colors.grey),
                                          ),
                                        ),
                                        Container(
                                          height: 5,
                                        ),
                                        Container(
                                            alignment: Alignment.centerLeft,
                                            child: Row(
                                              children: <Widget>[
                                                Container(
                                                  alignment: Alignment
                                                      .centerRight,
                                                  child: Text("Walmart",
                                                      style: TextStyle(
                                                          color: Colors.black,
                                                          fontSize: 20)),
                                                ),
                                                Container(
                                                    alignment:
                                                    Alignment.centerRight,
                                                    child: Text(
                                                        "                                     \$37.99",
                                                        style: TextStyle(
                                                            color: Colors.black,
                                                            fontSize: 20))),
                                              ],
                                            )),
                                        Container(
                                          height: 5,
                                        ),
                                        Container(
                                            alignment: Alignment.centerLeft,
                                            child: Text("Groceries",
                                                style:
                                                TextStyle(color: Colors.grey))),
                                      ],
                                    ),
                                  ),
                                ),
                              )
                            ],
                          ),
                          Column(
                            children: <Widget>[
                              Card(
                                child: InkWell(
                                  splashColor: Colors.grey,
                                  onTap: () => print("Hello"),
                                  child: Container(
                                    padding: EdgeInsets.all(15),
                                    height: 102,
                                    width: 390,
                                    child: Column(
                                      children: <Widget>[
                                        Container(
                                          alignment: Alignment.centerLeft,
                                          child: Text(
                                            "Payment",
                                            style: TextStyle(
                                                color: Colors.grey),
                                          ),
                                        ),
                                        Container(
                                          height: 5,
                                        ),
                                        Container(
                                            alignment: Alignment.centerLeft,
                                            child: Row(
                                              children: <Widget>[
                                                Container(
                                                  alignment: Alignment
                                                      .centerRight,
                                                  child: Text("Costco",
                                                      style: TextStyle(
                                                          color: Colors.black,
                                                          fontSize: 20)),
                                                ),
                                                Container(
                                                    alignment:
                                                    Alignment.centerRight,
                                                    child: Text(
                                                        "                                       \$37.99",
                                                        style: TextStyle(
                                                            color: Colors.black,
                                                            fontSize: 20))),
                                              ],
                                            )),
                                        Container(
                                          height: 5,
                                        ),
                                        Container(
                                            alignment: Alignment.centerLeft,
                                            child: Text(
                                                "New Laptop and groceries",
                                                style:
                                                TextStyle(color: Colors.grey))),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                              Card(
                                child: InkWell(
                                  splashColor: Colors.grey,
                                  onTap: () => print("Hello"),
                                  child: Container(
                                    padding: EdgeInsets.all(15),
                                    height: 102,
                                    width: 390,
                                    child: Column(
                                      children: <Widget>[
                                        Container(
                                          alignment: Alignment.centerLeft,
                                          child: Text(
                                            "Payment",
                                            style: TextStyle(
                                                color: Colors.grey),
                                          ),
                                        ),
                                        Container(
                                          height: 5,
                                        ),
                                        Container(
                                            alignment: Alignment.centerLeft,
                                            child: Row(
                                              children: <Widget>[
                                                Container(
                                                  alignment: Alignment
                                                      .centerRight,
                                                  child: Text("Best Buy",
                                                      style: TextStyle(
                                                          color: Colors.black,
                                                          fontSize: 20)),
                                                ),
                                                Container(
                                                    alignment:
                                                    Alignment.centerRight,
                                                    child: Text(
                                                        "                                    \$37.99",
                                                        style: TextStyle(
                                                            color: Colors.black,
                                                            fontSize: 20))),
                                              ],
                                            )),
                                        Container(
                                          height: 5,
                                        ),
                                        Container(
                                            alignment: Alignment.centerLeft,
                                            child: Text(
                                                "New Laptop and groceries",
                                                style:
                                                TextStyle(color: Colors.grey))),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                              Card(
                                child: InkWell(
                                  splashColor: Colors.grey,
                                  onTap: () => print("Hello"),
                                  child: Container(
                                    padding: EdgeInsets.all(15),
                                    height: 102,
                                    width: 390,
                                    child: Column(
                                      children: <Widget>[
                                        Container(
                                          alignment: Alignment.centerLeft,
                                          child: Text(
                                            "Payment",
                                            style: TextStyle(
                                                color: Colors.grey),
                                          ),
                                        ),
                                        Container(
                                          height: 5,
                                        ),
                                        Container(
                                            alignment: Alignment.centerLeft,
                                            child: Row(
                                              children: <Widget>[
                                                Container(
                                                  alignment: Alignment
                                                      .centerRight,
                                                  child: Text("Best Buy",
                                                      style: TextStyle(
                                                          color: Colors.black,
                                                          fontSize: 20)),
                                                ),
                                                Container(
                                                    alignment:
                                                    Alignment.centerRight,
                                                    child: Text(
                                                        "                                    \$37.99",
                                                        style: TextStyle(
                                                            color: Colors.black,
                                                            fontSize: 20))),
                                              ],
                                            )),
                                        Container(
                                          height: 5,
                                        ),
                                        Container(
                                            alignment: Alignment.centerLeft,
                                            child: Text(
                                                "New Laptop and groceries",
                                                style:
                                                TextStyle(color: Colors.grey))),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                              Card(
                                child: InkWell(
                                  splashColor: Colors.grey,
                                  onTap: () => print("Hello"),
                                  child: Container(
                                    padding: EdgeInsets.all(15),
                                    height: 102,
                                    width: 390,
                                    child: Column(
                                      children: <Widget>[
                                        Container(
                                          alignment: Alignment.centerLeft,
                                          child: Text(
                                            "Payment",
                                            style: TextStyle(
                                                color: Colors.grey),
                                          ),
                                        ),
                                        Container(
                                          height: 5,
                                        ),
                                        Container(
                                            alignment: Alignment.centerLeft,
                                            child: Row(
                                              children: <Widget>[
                                                Container(
                                                  alignment: Alignment
                                                      .centerRight,
                                                  child: Text("Best Buy",
                                                      style: TextStyle(
                                                          color: Colors.black,
                                                          fontSize: 20)),
                                                ),
                                                Container(
                                                    alignment:
                                                    Alignment.centerRight,
                                                    child: Text(
                                                        "                                    \$37.99",
                                                        style: TextStyle(
                                                            color: Colors.black,
                                                            fontSize: 20))),
                                              ],
                                            )),
                                        Container(
                                          height: 5,
                                        ),
                                        Container(
                                            alignment: Alignment.centerLeft,
                                            child: Text(
                                                "New Laptop and groceries",
                                                style:
                                                TextStyle(color: Colors.grey))),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                              Card(
                                child: InkWell(
                                  splashColor: Colors.grey,
                                  onTap: () => print("Hello"),
                                  child: Container(
                                    padding: EdgeInsets.all(15),
                                    height: 102,
                                    width: 390,
                                    child: Column(
                                      children: <Widget>[
                                        Container(
                                          alignment: Alignment.centerLeft,
                                          child: Text(
                                            "Payment",
                                            style: TextStyle(
                                                color: Colors.grey),
                                          ),
                                        ),
                                        Container(
                                          height: 5,
                                        ),
                                        Container(
                                            alignment: Alignment.centerLeft,
                                            child: Row(
                                              children: <Widget>[
                                                Container(
                                                  alignment: Alignment
                                                      .centerRight,
                                                  child: Text("Best Buy",
                                                      style: TextStyle(
                                                          color: Colors.black,
                                                          fontSize: 20)),
                                                ),
                                                Container(
                                                    alignment:
                                                    Alignment.centerRight,
                                                    child: Text(
                                                        "                                    \$37.99",
                                                        style: TextStyle(
                                                            color: Colors.black,
                                                            fontSize: 20))),
                                              ],
                                            )),
                                        Container(
                                          height: 5,
                                        ),
                                        Container(
                                            alignment: Alignment.centerLeft,
                                            child: Text(
                                                "New Laptop and groceries",
                                                style:
                                                TextStyle(color: Colors.grey))),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                              Card(
                                child: InkWell(
                                  splashColor: Colors.grey,
                                  onTap: () => print("Hello"),
                                  child: Container(
                                    padding: EdgeInsets.all(15),
                                    height: 102,
                                    width: 390,
                                    child: Column(
                                      children: <Widget>[
                                        Container(
                                          alignment: Alignment.centerLeft,
                                          child: Text(
                                            "Payment",
                                            style: TextStyle(
                                                color: Colors.grey),
                                          ),
                                        ),
                                        Container(
                                          height: 5,
                                        ),
                                        Container(
                                            alignment: Alignment.centerLeft,
                                            child: Row(
                                              children: <Widget>[
                                                Container(
                                                  alignment: Alignment
                                                      .centerRight,
                                                  child: Text("Best Buy",
                                                      style: TextStyle(
                                                          color: Colors.black,
                                                          fontSize: 20)),
                                                ),
                                                Container(
                                                    alignment:
                                                    Alignment.centerRight,
                                                    child: Text(
                                                        "                                    \$37.99",
                                                        style: TextStyle(
                                                            color: Colors.black,
                                                            fontSize: 20))),
                                              ],
                                            )),
                                        Container(
                                          height: 5,
                                        ),
                                        Container(
                                            alignment: Alignment.centerLeft,
                                            child: Text(
                                                "New Laptop and groceries",
                                                style:
                                                TextStyle(color: Colors.grey))),
                                      ],
                                    ),
                                  ),
                                ),
                              )
                            ],
                          )
                        ],
                      ),
                    ),
                    Container(
                      height: 280,
                      alignment: Alignment.bottomRight,
                      padding: EdgeInsets.all(10),
                      child: FloatingActionButton(
                        onPressed: () => print("Hello"),
                        splashColor: Colors.grey,
                        child: Icon(Icons.add),
                      ),
                    )
                  ],
                )
              ],
            ),
          ),
        ));
  }
}