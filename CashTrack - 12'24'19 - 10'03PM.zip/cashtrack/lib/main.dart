//Class Imports
import 'loginpage.dart';
import 'signuppage.dart';
import 'homepage.dart';

//Library Imports
import 'package:flutter/material.dart';

//Main Run Function
void main() => runApp(SplashScreen());

//Splash Screen Class
class SplashScreen extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return new MaterialApp(
      home: LoginInPage(),
      routes: <String, WidgetBuilder>{
        '/loginpage': (BuildContext context) => new LoginInPage(),
        '/signuppage' : (BuildContext context) => new SignUpPage(),
        '/homepage' : (BuildContext context) => new MyApp()
      },
    );
  }
}



