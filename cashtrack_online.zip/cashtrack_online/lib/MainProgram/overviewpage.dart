//Library Imports
import 'package:cashtrack_online/dataManagement/datamanagement.dart';
import 'package:cashtrack_online/applicationManagement.dart';
import 'package:fancy_dialog/FancyGif.dart';
import 'package:fancy_dialog/FancyTheme.dart';
import 'package:firebase_database/firebase_database.dart';

//Package Imports
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:jiffy/jiffy.dart';
import 'dart:async';
import 'package:liquid_pull_to_refresh/liquid_pull_to_refresh.dart';
import 'package:fancy_dialog/fancy_dialog.dart';

//Stateful Widget Class
class OverViewPage extends StatefulWidget {
  @override
  OverViewPageState createState() => OverViewPageState();
}

//State Class
class OverViewPageState extends State<OverViewPage> {
  //Instance Variables
  var databaseReference = FirebaseDatabase.instance.reference();
  var applicationManagementInstance = ApplicationManagement();
  var dataManagementInstance = DataManagement();

  //Global Variables
  var p = [];
  double totalCost = 0;
  double monthlyCost = 0;

  Future<List> updateListData() async {
    p = [];
    await Future.delayed(Duration(milliseconds: 700));
    await checkServerStatus();
    p = await dataManagementInstance.getAllPurchaseData();
    print("OLD P is: " + p.toString());
    getTotalCost();
    getMonthlyCost();
    print("TOTAL COST IS: "+ totalCost.toString());
    print("TOTAL COST IS: "+ totalCost.toString());
    setState(() {

    });
  }

  void getTotalCost(){
    totalCost = 0;
    for(int i = 0; i <= p.length-1; i++){
      totalCost = totalCost + p[i][1];
    }
  }

  void getMonthlyCost(){
    monthlyCost = 0;
    var now = DateTime.now();
    var currentMonth = Jiffy(now).month;

    for(int i = 0; i <= p.length-1; i++){
      if(p[i][4] == currentMonth){
        monthlyCost = monthlyCost + p[i][1];
      }
      print("MONTHLY COST IS: "+ monthlyCost.toString());
    }
  }
  @override
  void initState() {
    updateListData().then((value) {
      print('Async done');
      print("P VALUE IS: " + p.toString());
      updateListData();
      setState(() {});
    });
    super.initState();
  }

  checkServerStatus() async {
    var state = await applicationManagementInstance.CheckServersState();
    var shutdownMessage =
        await applicationManagementInstance.getShutdownMessage();
    print("working");
    print(state.toString());

    if (state == false) {
      showAlertDialog(shutdownMessage);
    }
  }

  showAlertDialog(shutdownMessage) {
    AwesomeDialog(
        context: context,
        dialogType: DialogType.WARNING,
        animType: AnimType.SCALE,
        tittle: 'Error',
        desc: 'Servers are down \n $shutdownMessage',
        onDissmissCallback: () => {SystemNavigator.pop()},
        btnOkText: 'Exit App',
        dismissOnTouchOutside: false,
        //btnCancelOnPress: () {SystemNavigator.pop();},
        btnOkOnPress: () {
          SystemNavigator.pop();
        }).show();
  }

  Future<void> _handleRefresh() async {
    await updateListData();
    print("refresh Finished");
    setState(() {});
  }

  void deletePopup(store){
    AwesomeDialog(
        context: context,
        dialogType: DialogType.INFO,
        animType: AnimType.SCALE,
        tittle: 'Delete?',
        desc: 'Are you sure you want to prementantly delete this purchase? \n From: $store',
        onDissmissCallback: () {print("Canceled");},
        btnOkText: 'Yes',
        btnCancelText: 'No',
        dismissOnTouchOutside: true,
        btnCancelOnPress: () {print("Canceled");Navigator.of(context).pop();},
        btnOkOnPress: () {
          print("Deleted");Navigator.of(context).pop();
        }).show();

  }

  //Main GUI BUILD for Class
  @override
  Widget build(BuildContext context) {
    SystemChrome.setEnabledSystemUIOverlays([]);
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    return new MaterialApp(
        home: Scaffold(
      backgroundColor: Colors.grey.shade200,
      body: Container(
              color: Colors.white10,
              child: Column(
                children: <Widget>[
                  new Stack(
                    children: <Widget>[
                      Container(
                        height: 310,
                        decoration: BoxDecoration(
                            gradient: LinearGradient(
                                begin: Alignment.topRight,
                                end: Alignment.bottomLeft,
                                colors: [
                              Colors.orangeAccent,
                              Colors.red,
                            ])),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(vertical: 120),
                        alignment: Alignment.center,
                        child: Text(
                          "Monthly Spendings",
                          style: TextStyle(
                              fontSize: 18,
                              color: Colors.white,
                              fontFamily: 'RobotoMono'),
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(vertical: 150),
                        alignment: Alignment.center,
                        child: Text(
                          "\$"+monthlyCost.toStringAsFixed(2),
                          style: TextStyle(
                            fontSize: 40,
                            color: Colors.white,
                          ),
                        ),
                      ),
                      Positioned(
                        top: 275,
                        left: 22,
                        child: Container(
                          height: 65,
                          width: 370,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: new BorderRadius.circular(5),
                            boxShadow: [
                              new BoxShadow(color: Colors.grey, blurRadius: 30)
                            ],
                          ),
                          child: Column(
                            children: <Widget>[
                              Text(
                                "\$" + totalCost.toStringAsFixed(2),
                                style: TextStyle(
                                    fontSize: 35, color: Colors.black),
                              ),
                              Text(
                                "Total Spendings",
                                style: TextStyle(
                                  color: Colors.grey,
                                  fontSize: 15,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                  Container(
                    height: 3,
                  ),
                  Text(
                    "Recent Activity",
                    style: TextStyle(fontSize: 20),
                  ),
                  Stack(
                    children: <Widget>[
                      Container(
                        height: 300.0,
                        child: LiquidPullToRefresh(
                          springAnimationDurationInMilliseconds: 500,
                          backgroundColor: Colors.white,
                          color: Colors.orange,
                          showChildOpacityTransition: true,
                          onRefresh: () async {
                            _handleRefresh();
                            return await Future.delayed(Duration(milliseconds: 500));
                          },
                          child: ListView.builder(
                            physics: BouncingScrollPhysics(),
                            scrollDirection: Axis.vertical,
                            itemCount: p.length,
                            itemBuilder: (context, int index) {
                              return Container(
                                height: 120,
                                width: 900,
                                child: ListView(
                                  physics: BouncingScrollPhysics(),
                                  scrollDirection: Axis.horizontal,
                                  children: <Widget>[
                                    Card(
                                      child: InkWell(
                                        splashColor: Colors.grey,
                                        child: Container(
                                          padding: EdgeInsets.all(15),
                                          height: 114,
                                          width: 400,
                                          child: Column(
                                            children: <Widget>[
                                              Container(
                                                alignment: Alignment.centerLeft,
                                                child: Text(p[index][0],
                                                    style: TextStyle(
                                                        color: Colors.black,
                                                        fontSize: 20)),
                                              ),
                                              Container(
                                                  alignment:
                                                  Alignment.centerRight,
                                                  child: Text(
                                                      "\$" +
                                                          p[index][1].toString(),
                                                      style: TextStyle(
                                                        color: Colors.black,
                                                        fontSize: 20,
                                                      ))),
                                              Container(
                                                  height: 30,
                                                  alignment: Alignment.bottomLeft,
                                                  child: Text(p[index][2],
                                                      style: TextStyle(
                                                          color: Colors.grey))),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      height: 109,
                                      width: 150,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      child: Card(
                                        color: Colors.red,
                                        child: InkWell(
                                          onTap: () {
                                            showDialog(
                                              context: context,
                                              builder: (BuildContext context) => FancyDialog(
                                                title: "Delete?",
                                                descreption: "Are you sure you want to delete this purchase?",
                                                ok: "Delete",
                                                cancel: "Cancel",
                                                okColor: Colors.red,
                                                theme: FancyTheme.FANCY,
                                                gifPath: FancyGif.PLAY_MEDIA,
                                                cancelFun: () {
                                                  print("canceled");
                                                },
                                                okFun: () async{
                                                  print("deleted");
                                                  dataManagementInstance.deletePurchase(p[index][3]);
                                                  await updateListData();
                                                  setState(() {
                                                  });
                                                },
                                              )
                                            );

                                            },
                                          splashColor: Colors.grey,
                                          child: Icon(
                                            Icons.delete_forever,
                                            color: Colors.white,
                                            size: 40,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            },
                          ),
                        ),
                      ),
                    ],
                  )
                ],
              ),
            ),
    ));
  }
}
