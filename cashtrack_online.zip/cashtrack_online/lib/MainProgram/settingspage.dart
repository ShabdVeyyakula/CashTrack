import 'package:flutter/material.dart';
//Library Imports
import 'package:cashtrack_online/dataManagement/datamanagement.dart';
import 'package:cashtrack_online/applicationManagement.dart';
import 'package:fancy_dialog/FancyGif.dart';
import 'package:fancy_dialog/FancyTheme.dart';
import 'package:firebase_database/firebase_database.dart';

//Package Imports
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:jiffy/jiffy.dart';
import 'dart:async';
import 'package:liquid_pull_to_refresh/liquid_pull_to_refresh.dart';
import 'package:fancy_dialog/fancy_dialog.dart';


class SettingsPage extends StatefulWidget{
  @override
  SettingsPageState createState() => SettingsPageState();
}

class SettingsPageState extends State<SettingsPage>{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return MaterialApp(
      home: Scaffold(
        appBar: PreferredSize(
          preferredSize: Size.fromHeight(240.0),
          child: AppBar(
            title: Container(
              alignment: Alignment.center,
              child: Text("Settings",),

            ),
            backgroundColor: Colors.deepOrangeAccent,


            flexibleSpace: FlexibleSpaceBar(
              centerTitle: true,
              title: Center(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Icon(
                      Icons.account_circle,
                      size: 70.0,
                      color: Colors.white,
                    ),
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Text(
                          'Account Name',
                          style: TextStyle(color: Colors.white),
                        ),
                        Text(
                          'Email Address',
                          style: TextStyle(color: Colors.white),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
      ),


      body: SafeArea(
        child: CustomScrollView(
          shrinkWrap: true,
          slivers: <Widget>[
            SliverPadding(
              padding: const EdgeInsets.all(20.0),
              sliver: SliverList(
                delegate: SliverChildListDelegate(
                  <Widget>[
                    GestureDetector(
                        onTap: () { print("Container was tapped"); },
                        child: Container(
                          child: Row(
                            children: <Widget>[
                              Expanded(
                                child: Text('Edit Profile', textAlign: TextAlign.left, style: TextStyle(fontSize: 20.0, color: Colors.blue.shade900  ),),
                              ),
                              Expanded(
                                child: Container(
                                  width: 100,
                                ),
                              ),
                              Icon(
                                Icons.arrow_forward_ios,
                                color: Colors.deepOrange
                              ),
                            ],
                          )
                        ),
                    ),

                    Container(
                      height: 30,
                    ),

                    GestureDetector(
                      onTap: () {
                        showDialog(
                            context: context,
                            builder: (BuildContext context) => FancyDialog(
                              title: "Change Password?",
                              descreption: "Are you Sure you want to change your password?",
                              ok: "Yes",
                              cancel: "Cancel",
                              okColor: Colors.red,
                              theme: FancyTheme.FANCY,
                              cancelFun: () {
                                print("canceled");
                              },
                              okFun: () async{
                                print("Password Changed");
                                setState(() {
                                });
                              },
                            )
                        );

                      },                      child: Container(
                          child: Row(
                            children: <Widget>[
                              Expanded(
                                child: Text('Change Password', textAlign: TextAlign.left, style: TextStyle(fontSize: 20.0, color: Colors.blue.shade900  ),),
                              ),
                              Expanded(
                                child: Container(
                                  width: 100,
                                ),
                              ),
                              Icon(
                                  Icons.arrow_forward_ios,
                                  color: Colors.deepOrange
                              ),
                            ],
                          )
                      ),
                    ),

                    Container(
                      height: 30,
                    ),
                    GestureDetector(
                      onTap: () { print("Container was tapped"); },
                      child: Container(
                          child: Row(
                            children: <Widget>[
                              Expanded(
                                child: Text('Email', textAlign: TextAlign.left, style: TextStyle(fontSize: 20.0, color: Colors.blue.shade900  ),),
                              ),
                              Expanded(
                                child: Container(
                                  width: 100,
                                ),
                              ),
                              Icon(
                                  Icons.arrow_forward_ios,
                                  color: Colors.deepOrange
                              ),
                            ],
                          )
                      ),
                    ),

                    Container(
                      height: 30,
                    ),
                    GestureDetector(
                      onTap: () { print("Container was tapped"); },
                      child: Container(
                          child: Row(
                            children: <Widget>[
                              Expanded(
                                child: Text('Notices', textAlign: TextAlign.left, style: TextStyle(fontSize: 20.0, color: Colors.blue.shade900  ),),
                              ),
                              Expanded(
                                child: Container(
                                  width: 100,
                                ),
                              ),
                              Icon(
                                  Icons.arrow_forward_ios,
                                  color: Colors.deepOrange
                              ),
                            ],
                          )
                      ),
                    ),

                    Container(
                      height: 30,
                    ),
                    GestureDetector(
                      onTap: () { print("Container was tapped"); },
                      child: Container(
                          child: Row(
                            children: <Widget>[
                              Expanded(
                                child: Text('Language', textAlign: TextAlign.left, style: TextStyle(fontSize: 20.0, color: Colors.blue.shade900  ),),
                              ),
                              Expanded(
                                child: Container(
                                  width: 100,
                                ),
                              ),
                              Icon(
                                  Icons.arrow_forward_ios,
                                  color: Colors.deepOrange
                              ),
                            ],
                          )
                      ),
                    ),

                    Container(
                      height: 30,
                    ),
                    GestureDetector(
                      onTap: () {
                        showDialog(
                            context: context,
                            builder: (BuildContext context) => FancyDialog(
                              title: "Clear  Data?",
                              descreption: "Are you Sure you want to clear all your data? This action cannot be undone!",
                              ok: "Yes",
                              cancel: "Cancel",
                              okColor: Colors.red,
                              theme: FancyTheme.FANCY,
                              cancelFun: () {
                                print("canceled");
                              },
                              okFun: () async{
                                print("Data Cleared");
                                setState(() {
                                });
                              },
                            )
                        );

                      },                      child: Container(
                          child: Row(
                            children: <Widget>[
                              Expanded(
                                child: Text('Clear All Purchase Data', textAlign: TextAlign.left, style: TextStyle(fontSize: 20.0, color: Colors.blue.shade900  ),),
                              ),
                              Expanded(
                                child: Container(
                                  width: 100,
                                ),
                              ),
                              Icon(
                                  Icons.arrow_forward_ios,
                                  color: Colors.deepOrange
                              ),
                            ],
                          )
                      ),
                    ),

                    Container(
                      height: 30,
                    ),
                    GestureDetector(
                      onTap: () {
                        showDialog(
                            context: context,
                            builder: (BuildContext context) => FancyDialog(
                              title: "Delete",
                              descreption: "Are you Sure you want to delete your account?  This action cannot be undone!",
                              ok: "Yes",
                              cancel: "Cancel",
                              okColor: Colors.red,
                              theme: FancyTheme.FANCY,
                              cancelFun: () {
                                print("canceled");
                              },
                              okFun: () async{
                                print("Account Deleted");
                                setState(() {
                                });
                              },
                            )
                        );

                      },                      child: Container(
                          child: Row(
                            children: <Widget>[
                              Expanded(
                                child: Text('Delete Account', textAlign: TextAlign.left, style: TextStyle(fontSize: 20.0, color: Colors.blue.shade900  ),),
                              ),
                              Expanded(
                                child: Container(
                                  width: 100,
                                ),
                              ),
                              Icon(
                                  Icons.arrow_forward_ios,
                                  color: Colors.deepOrange
                              ),
                            ],
                          )
                      ),
                    ),

                    Container(
                      height: 30,
                    ),

                    GestureDetector(
                      onTap: () { print("Container was tapped"); },
                      child: Container(
                          child: Row(
                            children: <Widget>[
                              Expanded(
                                child: Text('About', textAlign: TextAlign.left, style: TextStyle(fontSize: 20.0, color: Colors.blue.shade900  ),),
                              ),
                              Expanded(
                                child: Container(
                                  width: 100,
                                ),
                              ),
                              Icon(
                                  Icons.arrow_forward_ios,
                                  color: Colors.deepOrange
                              ),
                            ],
                          )
                      ),
                    ),

                    Container(
                      height: 30,
                    ),


                  ],
                ),
              ),
            ),
          ],
        ),

      ),
    ));
  }
}