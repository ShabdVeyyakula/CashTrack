import 'package:firebase_database/firebase_database.dart';

class ApplicationManagement{

  var databaseReference = FirebaseDatabase.instance.reference();

  Future CheckServersState() async{
    DataSnapshot serversChecker = await databaseReference
        .reference()
        .child("ApplicationManagement")
        .child("serversAreUp")
        .once();

    return serversChecker.value;

  }

  Future getShutdownMessage() async{
    DataSnapshot serversChecker = await databaseReference
        .reference()
        .child("ApplicationManagement")
        .child("shutdownMessage")
        .once();

    return serversChecker.value;

  }

  Future getLatestVersion() async{
    DataSnapshot appChecker = await databaseReference
        .reference()
        .child("ApplicationManagement")
        .child("latestAppVersion")
        .once();

    return appChecker.value;

  }
}